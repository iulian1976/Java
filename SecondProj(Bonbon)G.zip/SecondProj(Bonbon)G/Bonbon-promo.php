﻿<?php
// démarre session
session_start();


?>

<!DOCTYPE html>
<html lang="fr" >

<head>
<meta  charset="utf-8">
 <link rel="stylesheet" type="text/css" href="assets/style.css">
 <meta name="Munich" content="tout sur Munich">
 <meta name="author" content="Amariei Iulian">
 <meta name="keywords" content="html web ville">
 <link rel="stylesheet" type="text/css" href="assets/style.css">
<title>Bonbon et Tradition</title>
</head>
<body>
<?php	
if(isset($_SESSION['user']))
{	
echo  'Bonjour,'.$_SESSION['user']; 
echo  '<a href="formulaire.php">Déconnexion </a> </br>';	
}
else
{	
echo  'Bonjour,Guest'; 
echo  '<a href="formulaire.php">Déconnexion </a> </br>';	
}	
?>		
<div id="haut"></div> 
<header>
<div class="titre1">
                            <img src="assets/imageheader/logobonbon.png" class="image2" alt="Logo Bonbon" />
                            <h1>Bonjour!Tout ce que vous devrez savoir sur les bonbon</h1>
         </div>

        <nav class="mainmenu">
                           <ul>
	                         <li><a href="index.php?id=1">Accueil</a></li>
                             <li><a href="Bonbon-list.php">Liste de bonbon</a></li>
                             <li><a href="Bonbon-promo.php">Promos</a></li>
                             <li><a href="index.php?id=2">Contact</a></li>
		                   </ul>
         </nav>
</header>

<div id="panoramic">
 <div class="direction">
<h1>Promotion...</h1>
</div>
</div>


<section class="center">

<table class="t">

<?php	
try {
 
//$c=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
$c=new PDO('mysql:host=localhost;dbname=bonbon','root', 'iuli',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));	

}
catch(PDOException $e) {
    echo $e->getMessage();
}
		 
$req='SELECT * FROM liste';

$res=$c->query($req);
$i=0;
echo '<h1>Nos sortimentes des bonbons</h1> <br/>';
echo '<tr><td></td><td></td><td></td></tr>';
while($e=$res->fetch())  
{
 $id=$e['id'];
 $designation=$e['designation'];
 $description=$e['description'];
 $photo=$e['photo'];
 $quantite=$e['quantite'];
 $prix=$e['prix'];
 $prixpromo=$e['prixpromo'];	
 $etatpromo=$e['etatpromo'];
 
 if($etatpromo==1) $i=$i+1;	
 	

 
	
 if ($etatpromo==1 && $prixpromo!=0&&$quantite!=0)
 {	  
 echo  '<tr><td rowspan="2"> <a href="" class="par"><img src="'.$photo.'" alt="photobonbon"/></a></td><td></td><td>'.$designation.'</td></tr>'; 
 echo  '<tr><td ></td><td >'.$description.'</td></tr>';
 echo  '<tr  class="prix"><td ></td><td ><input type="number" class="quant" min="0" max="20"/></td><td>'.$prix.'€ <a href="" class="bouton1"><?php include("includes/b1.php"); ?> </a> </td></tr>';
 }	
}	
 
if ($i==0) echo '<h1>Desolé,Nous n\'avons pas des produits en promotion!</h1>';		
?>		
</table>	
</section>
<footer>
  <nav class="Contact">
      <h2>Contact&Diverces</h2>
      
         <a href="https://www.facebook.de/muenchen"><img src="assets/imagefooter/facebook1.png" alt="logoface"/></a>
         <a href="https://plus.google.com/+muenchende"><img src="assets/imagefooter/google.png" alt="logog"/></a>
		 <a href="https://twitter.com/muenchen_de"><img src="assets/imagefooter/twitter.png" alt="logotwit"/></a>
         <a href="https://www.youtube.com/user/MUENCHENdeVIDEOS"><img src="assets/imagefooter/youtube.png" alt="logoypu"/></a>
         <a href="https://www.instagram.com/muenchen/"><img src="assets/imagefooter/instagram.png" alt="logoinst"/></a>
</nav>

<nav class="Services">
      <h2>Services</h2>
      
            <a href="http://www.muenchen.de/stadtplan.html"><img src="assets/imagefooter/carte.png" alt="logostadt"/>Geolocalisation</a>
            <a href="http://bonbonsdegrandmere.be/fr/content/7-nos-points-de-vente"><img src="assets/imagefooter/intinerar.png" alt="logostadt"/>Points de vente</a>
		    <a href="http://www.muenchen.de/essen-trinken.html"><img src="assets/imagefooter/restaurant.png" alt="logoessen"/>Nouveaux produits</a>	
</nav> 
   <a href="#haut"><img src="assets/imagefooter/ancore1.png" class="ancore" alt="up"/></a>  
</footer>

 <div class="webmaster"> © 2017 ReinerI reineriuli@gmail.com</div> <a href="formulaire.php" class="bouton1">Restricted Area<img src="assets/imagecenter/click1.png" alt="boutton4"/> </a>
</body>
</html>
                                                      
