

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
   <meta name="Munich" content="tout sur bonbon">
   <meta name="author" content="Amariei Iulian">
   <meta name="keywords" content="html web bonbon">
   <link rel="stylesheet" type="text/css" href="assets/style.css">
 <title>Contactez-nous</title>
</head>
<body>

<div class="titre1">
                       
         </div>

        <nav class="mainmenu">
                          
	                         <li><a href="index.php?id=1" class="bouton1">Accueil</a></li>
                             <li><a href="Bonbon-list.php" class="bouton1">Liste de bonbon</a></li>
                             <li><a href="Bonbon-promo.php" class="bouton1">Promos</a></li>
                             <li><a href="page.php?id=2" class="bouton1">Contact</a></li>
							
		                   
         </nav>



<form  method="post"  action="go.php">

    <p>
     <br/><input type="text" name="nom" placeholder="Votre nom"><br/>
	 <br/><input type="password" name="pass" placeholder="pass"><br/>
    <input type="submit"  value="Connexion" class="bouton1"></p>
</form>
	
<?php	
	
	
	if(isset($_GET['connect'])) 
	{
	$c=$_GET['connect'];
	}
	
	else $c='';

   if($c=='false') echo '*erreur nome ou mot passe';

?>



</body>
</html>
                                                      
