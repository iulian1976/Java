﻿<?php
// démarre session
session_start();
//$_SESSION['user']='Guest';



?>


<!DOCTYPE html>
<html lang="fr">

   <head>
   <meta charset="utf-8"/> 
   <meta name="Munich" content="tout sur bonbon">
   <meta name="author" content="Amariei Iulian">
   <meta name="keywords" content="html BONBON">
   <link rel="stylesheet" type="text/css" href="assets/style.css">
   <title> Visiter La patrie de bonbon</title>
  </head>
<body>
<?php
if(isset($_SESSION['user']))
{	
echo  'Bonjour,'.$_SESSION['user']; 
echo  '<a href="formulaire.php">Déconnexion </a> </br>';	
}
else
{	
echo  'Bonjour,Guest'; 
echo  '<a href="formulaire.php"> </a> </br>';	
}	
	
	


	
try {
   
   // $c=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
	$c=new PDO('mysql:host=localhost;dbname=bonbon','root', 'iuli',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
	
}
catch(PDOException $e) 
{
    echo $e->getMessage();
}

$id=1;

if(isset($_GET['id']))
{	
$id=$_GET['id'];
}
	

$req='SELECT * FROM  page  WHERE id='.$id ;
$res=$c->query($req);


while($e=$res->fetch())
{           
				   $titre=$e['titre'];
				   $contenu=$e['contenu'];	
                   $photo=$e['photo']; 				   
}

?>  

   <header>
 <span id="haut"></span> 



   
   <div class="titre1">
                            <img src="assets/imageheader/logobonbon.png" class="image2" alt="Logobonbon" />
                            <h1><?php echo $titre ?></h1>
         </div>

        <nav class="mainmenu">
                           <ul>
	                         <li><a href="index.php?id=1">Accueil</a></li>
                             <li><a href="Bonbon-list.php">Liste de bonbon</a></li>
                             <li><a href="Bonbon-promo.php">Promos</a></li>
                             <li><a href="index.php?id=2">Contact</a></li>
		                   </ul>
         </nav>
   	
    </header>
 
    <section>
     <?php 
	 
	 echo $contenu;
	 
	 echo  '<img src="'.$photo.'" class="bonbon1" alt="direction"/>' ;

	 ?>
       
   </section>
   
   
   
   
 
<footer>
     <nav class="Contact">
      <h2>Contact&Diverces</h2>
         <a href="https://www.facebook.de/muenchen"><img src="assets/imagefooter/facebook1.png" alt="logoface"/></a>
         <a href="https://plus.google.com/+muenchende"><img src="assets/imagefooter/google.png" alt="logog"/></a>
		 <a href="https://twitter.com/muenchen_de"><img src="assets/imagefooter/twitter.png" alt="logotwit"/></a>
         <a href="https://www.youtube.com/user/MUENCHENdeVIDEOS"><img src="assets/imagefooter/youtube.png" alt="logoypu"/></a>
         <a href="https://www.instagram.com/muenchen/"><img src="assets/imagefooter/instagram.png" alt="logoinst"/></a>
</nav>

<nav class="Services">
      <h2>Services</h2>
      
            <a href="http://www.muenchen.de/stadtplan.html"><img src="assets/imagefooter/carte.png" alt="logostadt"/>Geolocalisation</a>
            <a href="http://bonbonsdegrandmere.be/fr/content/7-nos-points-de-vente"><img src="assets/imagefooter/intinerar.png" alt="logostadt"/>Points de vente</a>
		    <a href="http://www.muenchen.de/essen-trinken.html"><img src="assets/imagefooter/restaurant.png" alt="logoessen"/>Nouveaux produits</a>	
</nav> 
   <a href="#haut"><img src="assets/imagefooter/ancore1.png" class="ancore" alt="up"/></a>                                                                                        
</footer>
 
 <div class="webmaster"> © 2017 ReinerI reineriuli@gmail.com</div> <a href="formulaire.php" class="bouton1">Restricted Area<img src="assets/imagecenter/click1.png" alt="boutton4"/> </a>
</body>

</html>
                                                      
