<?php
// démarre session
session_start();

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta  charset="utf-8">
   <meta name="Munich" content="tout sur Munich">
   <meta name="author" content="Amariei Iulian">
   <meta name="keywords" content="html web ville">
   <link rel="stylesheet" type="text/css" href="assets/style.css">
 <title>Contactez-nous</title>
</head>

<body>




  <?php
	
	 
    // pour supprimer une ligne-------->
      if(isset($_POST['ids']))
      {
		
     // $bdd=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
	  $bdd=new PDO('mysql:host=localhost;dbname=bonbon','root', 'iuli',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));	  
	
	 
      $ids=$_POST['ids']; 
	  $req=$bdd->query('DELETE FROM liste WHERE id='.$ids);
     
	  unset($_POST);
      header('location:outilMyAdmin.php?ids1=$ids');
	  header('location:outilMyAdmin.php?menu=1');
                                      // pour charger ids pour delete 
	 
	
     }//<-------- pour supprimer une ligne
	
	
	//-------->pour choisie in $idm une ligne 
	if(isset($_POST['idm']))
    {
	 $idm=$_POST['idm'];
	 echo $idm;
     header('location:outilMyAdmin.php?idm1='.$idm.'');                             
    }//<-------- pour choisir $idm 
	
	
	
	
		
	//  ---> raj une ligne+photo
	
	if(isset($_FILES['photoaj'])&&$_FILES['pphotoaj']['error']==0)
	{
       
	   if($_FILES['pphoto']['size']<=1000000)
	   {
          move_uploaded_file($_FILES['photoaj']['tmp_name'], 'assets/imagecenter/'. basename($_FILES['photoaj']['name']));
          echo "L'envoi ok";
		  
          $pathfix=$_FILES['photoaj']['name'];
		  // le nom photo
           
		  $pathpre="assets/imagecenter/";
          $pathprefix= $pathpre."".$pathfix;
		  
		 // $pathpre="assets/imagecenter/";
         // $pathprefix='<img src="'.$pathpre.''.$pathfix.'"class="bonbon1" alt="direction"/> ';
		 // 2-eme methode  
		  // echo 	$pathprefix;
		  // ok path total :)
	   }	  
    }    
  
    
	if(isset($_POST['designation'])&&isset($_POST['description'])&&isset($_POST['prix'])&&isset($_POST['prixpromo'])&&isset($_POST['quantite']))
    {
    $bdd=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
	
	$req=$bdd->prepare('INSERT INTO liste(designation,description,prix,prixpromo,quantite,photo) VALUES(?,?,?,?,?,?)');
    $req->execute(array($_POST['designation'], $_POST['description'], $_POST['prix'],$_POST['prixpromo'], $_POST['quantite'],$pathprefix ));
	                                                                                                                        // photo chargée  
    header('location:outilMyAdmin.php?menu=1');
    }// <------------pour rajoute une ligne+photo
	
	//--------> modif ligne+photo dans la liste 
	if(isset($_FILES['photomodif'])&&$_FILES['photomodif']['error']==0)
	{
       
	   if($_FILES['photomodif']['size']<=1000000)
	   {
          move_uploaded_file($_FILES['photomodif']['tmp_name'], 'assets/imagecenter/'. basename($_FILES['photomodif']['name']));
          
		  
          $pathfix=$_FILES['photomodif']['name'];
		  // le nom photo
           
		  $pathpre="assets/imagecenter/";
          $pathprefix= $pathpre."".$pathfix;
		  
		 // $pathpre="assets/imagecenter/";
         // $pathprefix='<img src="'.$pathpre.''.$pathfix.'"class="bonbon1" alt="direction"/> ';
		 // 2-eme methode  
		  // echo 	$pathprefix;
		  // ok path total :)   		  
       }       
    }
	
	
	if(isset($_POST['idm'])&&isset($_POST['mdesignation'])&&isset($_POST['mdescription'])&&isset($_POST['mprix'])&&($_POST['mquantite'])&&isset($_FILES['photomodif']))
    {	
     $bdd=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
  
		
	$idm=$_POST['idm'];
	//echo $_POST['']; 
	
    $req=$bdd->exec('UPDATE  liste SET designation="'.$_POST['mdesignation'].'",description="'.$_POST['mdescription'].'",prix="'.$_POST['mprix'].'",prixpromo="'.$_POST['mprixpromo'].'",quantite="'.$_POST['mquantite'].'",photo="'.$pathprefix.'" WHERE id='.$idm);
	
    }// <------pour modif une ligne bonbon+photo
	
	
	
	// ----->  modif Accueil&Contact+photo
	
    if(isset($_FILES['pphoto'])&&$_FILES['pphoto']['error']==0)
	{
       
	   if($_FILES['pphoto']['size']<=1000000)
	   {
          move_uploaded_file($_FILES['pphoto']['tmp_name'], 'assets/imagecenter/'. basename($_FILES['pphoto']['name']));
          echo "L'envoi ok";
		  
          $pathfix=$_FILES['pphoto']['name'];
		  // le nom photo
           
		  $pathpre="assets/imagecenter/";
          $pathprefix= $pathpre."".$pathfix;
		  
		 // $pathpre="assets/imagecenter/";
         // $pathprefix='<img src="'.$pathpre.''.$pathfix.'"class="bonbon1" alt="direction"/> ';
		 // 2-eme methode  
		  // echo 	$pathprefix;
		  // ok path total :)
           
         		  
       }    
	   
    }
	
	if(isset($_POST['ptitre'])&&isset($_POST['pcontenu']))
    {	
    $bdd=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
   				
	$idp=$_POST['idp'];
	  if($idp==2) 
     {		 
	 $cont =addslashes(html_entity_decode($_POST['pcontenu'],ENT_QUOTES)); 
	               // convert les caract spec--->en Html + convert / etc
	 
	
	$req=$bdd->exec('UPDATE  page SET titre="'.$_POST['ptitre'].'",contenu="'.$cont.'",photo="'.$pathprefix.'"  WHERE id='.$idp);
	    header('location:outilMyAdmin.php?menu22=2');
	}//
	    if($idp==1)
      {
       $idp=$_POST['idp'];
	
	  $req=$bdd->exec('UPDATE  page SET titre="'.$_POST['ptitre'].'",contenu="'.$_POST['pcontenu'].'",photo="'.$pathprefix.'"  WHERE id='.$idp);

		header('location:outilMyAdmin.php?menu22=1');
	   }
    }// <--------------pour modif soit accueil soit contact+photo
	                                                                                                                                                   
	
	// --->navigation menu
	
	 if((isset($_GET['menu22'])&&$_GET['menu22']==3))
	{		
	 unset($_GET);	
     header('location:outilMyAdmin.php');
	 } // <--------------pour retour menu
	
	
	if(isset($_POST['idpromo']))
    {	
	 $bdd=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));	
	 
	 $idp=$_POST['idpromo'];
	 $un=$_POST['un'];	
	 echo $idp;
	 echo $un;	
	
	 $req=$bdd->exec('UPDATE  liste SET etatpromo="'.$un.'"  WHERE id='.$idp);
	
	 header('location:outilMyAdmin.php?menu=1');
    }// <--------------pour modif etat en ouvert
	
	if(isset($_POST['iddz']))
    {	
      $bdd=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
	 
		
	 $idp=$_POST['iddz'];
	 $zero=$_POST['zero'];	
	 
	
	 $req=$bdd->exec('UPDATE  liste SET etatpromo="'.$zero.'"  WHERE id='.$idp);
	
	 header('location:outilMyAdmin.php?menu=1');
    }// <--------------pour modif etat en ouvert
	
	
	
	
	
	
	
     // header('location:outilMyAdmin.php');
?>
</body>

</html>





                                                      
