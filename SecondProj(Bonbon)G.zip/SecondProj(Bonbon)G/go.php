

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta  charset="utf-8">
   <meta name="Munich" content="tout sur Munich">
   <meta name="author" content="Amariei Iulian">
   <meta name="keywords" content="html web ville">
   <link rel="stylesheet" type="text/css" href="assets/style.css">
 <title>Contactez-nous</title>
</head>

<body>


<?php


$nom=$_POST['nom'];
$pass=$_POST['pass'];	


//$c=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));
$c=new PDO('mysql:host=localhost;dbname=bonbon','root', 'iuli',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));	

	
	
$req=' SELECT * FROM user ';
echo $req ;

$res=$c->query($req);


while($e=$res->fetch())
{
	
 $login=$e['login'];
 $pwd=$e['pwd'];



     
}


//echo $login;

if($nom==$login&&$pass==$pwd) header('location:outilMyAdmin.php?login1='.$login);

else header('location:formulaire.php?connect=false');
	// var connect vers form si c'est pas ok 

?>










</body>

</html>
                                                      
