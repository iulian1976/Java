<?php
// démarre session
session_start();

if(isset($_GET['login1']))
{	
$_SESSION['user']=$_GET['login1'];
 echo  'Bonjour,'.$_SESSION['user']; 
 echo  '	<a href="formulaire.php">Déconnexion </a> </br>';
}
else 
{	
echo  'Bonjour,'.$_SESSION['user'];
echo  '	<a href="formulaire.php">Déconnexion </a> </br>';
}	
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta  charset="utf-8">
   <meta name="Munich" content="tout sur bonbon">
   <meta name="author" content="Amariei Iulian">
   <meta name="keywords" content="html web bonbon">
   <link rel="stylesheet" type="text/css" href="assets/style.css">
   <title>Bonbon </title>
</head>
<body>
<header>
 <span id="haut"></span> 

   <div class="titre1">
                       
         </div>

        <nav class="mainmenu">
                          
	                         <li><a href="page.php?id=1" class="bouton1">Accueil</a></li>
                             <li><a href="Bonbon-list.php" class="bouton1">Liste de bonbon</a></li>
                             <li><a href="Bonbon-promo.php" class="bouton1">Promos</a></li>
                             <li><a href="page.php?id=2" class="bouton1">Contact</a></li>
							
		                   
         </nav>
   	
    </header>



<?php
  $c=new PDO('mysql:host=iutdoua-web.univ-lyon1.fr;dbname=p1514597','p1514597','249996',array(\PDO::MYSQL_ATTR_INIT_COMMAND =>  'SET NAMES utf8'));

 
 $req1='SELECT * FROM liste'; // pour gere liste bonbon
 

 
 $res1=$c->query($req1);
 
 

   
	
	
       if(!isset($_GET['menu'])&&!isset($_GET['idm1']))
	   {	 		 
   echo '<nav class="mainmenu">';
        echo   '<ul>';
	    echo   '<li><a href="outilMyAdmin.php?menu=1">-->Gestion de la liste de bonbon</a></li> </br>';
		echo   '</br>';
     	echo   '</br>';
		echo   '</br>';
		echo   ' </br>';
        echo   '<li><a href="outilMyAdmin.php?menu=2">-->Gestion page d accueil&Contact</a></li>';			
		echo   '</ul>';
        echo   '</nav>';
	   }		
	    
					         if(isset($_GET['menu'])&&$_GET['menu']==2&&!isset($_GET['idm1']))
					         {
						      echo '<nav class="mainmenu">'; 
							  echo   '<ul>';	 
                              echo   '<li><a href="outilMyAdmin.php?menu22=1">-->Gestion page d Accueil</a></li> </br>';
                              echo   '<li><a href="outilMyAdmin.php?menu22=2">-->Gestion page Contact</a></li> </br>';
							  echo   '<li><a href="redirect.php?menu22=3">-->Retour</a></li>';
							                // pour retour unset $_GET['menu'] par redirect.php
						      echo   '<ul>';
							  echo      '</nav>';
							 }
			 
  

//---------------->Modif Accueil&Contact  
 if(isset($_GET['menu22']))
{
	
 
	$req3='SELECT * FROM  page WHERE id='.$_GET['menu22']; // pour modif accueil
    $res=$c->query($req3);

	if($_GET['menu22']==1) $A='Accueil'  ;
    else  $A='Contact';	

 while($e=$res->fetch())
 {  
                   $idp=$e['id'];
				   $titre=$e['titre'];
				   $contenu=$e['contenu'];	
                   $photo=$e['photo']; 				   
 	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
 }  // <---------------modif page  soit pour Accueil soit pour Contact
 
     	 
  

     echo   '<li><a href="redirect.php?menu22=3">-->Retour</a></li>'; // pour retour
     echo '<table>';
     echo  '<tr><td>'.$A.'</td><td>titre</td><td>contenu</td><td>photo</td><td></td><td></td></tr>'; 
     echo  ' <form  method="post" action="redirect.php" enctype="multipart/form-data">';
	 echo  '<tr><td><input type="hidden" name="idp" value="'.$idp.'"></td><td ><p><textarea name="ptitre"  rows="2" cols="30" >'.$titre.'</textarea> </td><td><textarea name="pcontenu"rows="20" cols="60" >'.htmlspecialchars($contenu).'</textarea></td><td><img src="'.$photo.'" class="bonbon1" alt="direction"WIDTH=90 HEIGHT=90 /> </br>'.$photo.'<input type="file" name="pphoto" rows="2" cols="30"></td><td><input type="submit"  value="Modifier" class="bouton1"> </form></br><input type="button" onclick="window.location.reload(false)" value="Annuler" class="bouton1"></td></p></tr>';
                                         // name <---val                                                                                                                                                   // poar afiche corectement les entités html spéciales ---> caract
	 echo '</table>'; 
 
}     // <------input table pour Accueil ,soit Contact
   
   
   //------>Liste de bonbon
 
if((isset($_GET['menu'])&&$_GET['menu']==1)||isset($_GET['idm1']))
{                                          	

echo '<h1>Nos sortimentes des bonbons</h1> <br/>';
	
	
echo   '<li><a href="redirect.php?menu22=3">-->Retour</a></li>'; // pour retour

	
echo '<table>';


 echo '<tr><td>id</td><td>designation</td><td>description</td><td>quantite</td><td>prix</td><td>prixpromo</td><td>photo</td><td>etatpromo</td><td colspan="4"></td><td></td></tr>'; 
 while($e1=$res1->fetch())  
{
 $id=$e1['id'];
 $designation=$e1['designation'];
 $description=$e1['description'];
 $quantite=$e1['quantite'];
 $prix=$e1['prix'];
 $prixpromo=$e1['prixpromo'];	
 $photo=$e1['photo'];
 $etatpromo=$e1['etatpromo'];
	
$etatp='Fermé';	
if ($etatpromo==1)
{
$etatp='Ouvert';	
}
	
$un=1;
$zero=0;	
 
// value chechbox ==> val name
 echo  '<tr><td>'.$id.'</td><td>'.$designation.'</td><td >'.$description.'</td><td>'.$quantite.'</td><td>'.$prix.'€</td><td>'.$prixpromo.'€</td><td><img src="'.$photo.'" class="bonbon1" alt="direction"WIDTH=40 HEIGHT=40 /> <td>'.$etatp.' </td></td><td><form  method="post"  action="redirect.php"> <input type="checkbox" name="ids" value="'.$id.'" class="bouton1"> </td><td> <input type="submit"  value="Suprimmer" class="bouton1"></form></td><td> <form  method="post"  action="redirect.php"> <input type="checkbox" name="idm" value="'.$id.'" class="bouton1"> </td><td> <input type="submit"  value="Modifier" class="bouton1"></form></td> <td><form  method="post"  action="redirect.php"> <input type="hidden" name="un" value="'.$un.'"><input type="checkbox" name="idpromo" value="'.$id.'" class="bouton1"><input type="submit"  value="Activer la promotion" class="bouton1"></form> <form  method="post"  action="redirect.php"><input type="hidden" name="zero" value="'.$zero.'"> <input type="checkbox" name="iddz" value="'.$id.'" class="bouton1"><br/><input type="submit"  value="Desactiver la promotion" class="bouton1"></form></td></tr>'; 
                                                                     
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
}

 echo '<tr><td>id</td><td>designation</td><td>description</td><td>quantite</td><td>prix</td><td>prixpromo</td><td>photo</td><td>etatpromo</td><td colspan="4"></td><td></td></tr>'; 
  
  echo '</table>';
		
	// -----------> Chargement $id1 preparée pour modif	

if(isset($_GET['idm1']))
{
$req4='SELECT * FROM  liste WHERE id='.$_GET['idm1']; // pour modif accueil
$res=$c->query($req4);

while($e1=$res->fetch())  
{
if($e1['id']==$_GET['idm1'])
{	
 $designation=$e1['designation'];
 $description=$e1['description'];
 $quantite=$e1['quantite'];
 $prix=$e1['prix'];
 $prixpromo=$e1['prixpromo'];	
 $photo=$e1['photo'];
} 
$id=$_GET['idm1'];
}

}

//  <-------------------------------- fin chargement $id	
	

echo '<table>';
echo  '<tr><td>id</td><td>designation</td><td>description</td><td>quantite</td><td>prix</td><td>prixpromo</td><td>photo</td><td></td></tr>'; 
echo  '<tr><td>'.$id.'<form  method="post" action="redirect.php" enctype="multipart/form-data"><input type="hidden" name="idm" value="'.$id.'"></td><td><textarea name="mdesignation" >'.$designation.'</textarea></td><td><textarea name="mdescription" rows="20" cols="60" >'.$description.'</textarea></td><td><textarea name="mquantite" >'.$quantite.'</textarea></td><td><textarea name="mprix">'.$prix.'</textarea></td><td><textarea name="mprixpromo">'.$prixpromo.'</textarea></td><td><img src="'.$photo.'" class="bonbon1" alt="direction" WIDTH=90 HEIGHT=90 /> </br>'.$photo.'<input type="file" name="photomodif" value="'.$photo.'" rows="2" cols="30"></td><td><input type="submit"  value="Sauver une ligne modifiée" class="bouton1"</p></form></br><input type="button" onclick="window.location.reload(false)" value="Annuler" class="bouton1"></td></tr>';
                                      
echo '</table>';  

echo '<table>';
$id=$id+1;
echo  '<tr><td>id</td><td>designation</td><td>description</td><td>quantite</td><td>prix</td><td>prixpromo</td><td>photo</td><td></td></tr>'; 
echo  '<tr><td>'.$id.'<form  method="post"  action="redirect.php" enctype="multipart/form-data"></td><td > <input type="text" name="designation" placeholder="designation"></td><td><textarea name="description" placeholder="description" rows="20" cols="60"> </textarea></td><td><input type="text" name="quantite" placeholder="quantite"></td><td><input type="text" name="prix" placeholder="prix"></td><td><input type="text" name="prixpromo" placeholder="prixpromo"></td><td><img src="'.$photo.'" class="bonbon1" alt="direction" WIDTH=90 HEIGHT=90 /> </br>'.$photo.'<input type="file" name="photoaj" rows="2" cols="30"> </td><td><input type="submit"  value="Ajouter une ligne" class="bouton1"</p></form></br><input type="button" onclick="window.location.reload(false)" value="Annuler" class="bouton1"></td></tr>';
    
 echo '</table>';  
 //echo 'ligne a éte ajouté avec succes';
}
 ?>
</body>

</html>
                                                      
